'use server';

import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { getOffer, OFFER_ID_PATTERN, setOfferVariant } from '@/lib/offers';
import { priceForPick } from '@/lib/price-guide';
import { effectiveRates, getAudRates } from '@/lib/fx.mjs';
import { getLatestAssessment } from '@/lib/assessments';
import { savePhoto } from '@/lib/photos';
import { applyToWaiting, learnedRuleForOffer, saveOwnerDecision } from '@/lib/owner-decisions';
import { applyLearned, rulesHit, validateDecision } from '@/lib/owner-decisions.mjs';

import { getSettings } from '@/lib/settings';
import { confirmAssessment, createAssessment } from '@/lib/assessments';
import { validateAssessment } from '@/lib/assessment-fields';
import { assess, OUTCOMES } from '@/lib/assess.mjs';
import { buildSalesNote } from '@/lib/sales-note.mjs';
import { runAgent, SEARCHES_WITH_SALES } from '@/lib/agent';
import { countRunsLastDay, getLatestRun, saveRun, setRunPriceGuide } from '@/lib/agent-runs';
import { DAILY_LIMIT, startInBackground, verdictFromRun } from '@/lib/auto-assess';
import { cookies } from 'next/headers';
import { AGENT_COOKIE, agentToken, cookieOptions, isRemembered, passcodeOk } from '@/lib/agent-access';

function field(formData, name) {
  const v = formData.get(name);
  return typeof v === 'string' ? v.trim() : '';
}

const ASSESS_FIELDS = [
  'stock_count', 'condition', 'rookie_card', 'first_team', 'sales_count', 'median_sold_aud', 'evidence_source',
  'score_football', 'score_career', 'score_collector', 'score_card', 'score_valuation',
];

// Runs the owner's rules (plain code) on what staff entered, then saves the result.
export async function assessOffer(_prev, formData) {
  const offerId = field(formData, 'offer_id');
  const values = {};
  for (const k of ASSESS_FIELDS) values[k] = typeof formData.get(k) === 'string' ? formData.get(k) : '';
  const attempt = Date.now();
  const fail = (message, errors = {}) => ({ status: 'error', message, errors, values, attempt });
  if (!OFFER_ID_PATTERN.test(offerId)) return fail('This offer could not be found.');
  const check = validateAssessment(values);
  if (!check.ok) return fail('Please fix the highlighted fields.', check.errors);
  const [{ offer }, { settings, error: sErr }] = await Promise.all([getOffer(offerId), getSettings()]);
  if (!offer) return fail('This offer could not be found.');
  if (sErr) return fail(sErr);
  // Keep using the price guide value from the latest AI draft, if there is one.
  const { run: latest } = await getLatestRun(offerId);
  const guide = latest?.status === 'completed' && latest.price_guide?.found ? latest.price_guide.value_aud : null;
  const perYear = latest?.status === 'completed' && latest.price_guide?.found ? latest.price_guide.sales_per_year ?? null : null;
  const result = applyLearned(assess(offer, { ...check.input, price_guide_aud: guide, sales_per_year: perYear }, settings),
    offer, check.input, settings, await learnedRuleForOffer(offer));
  const runId = field(formData, 'agent_run_id');
  const agentRunId = OFFER_ID_PATTERN.test(runId) ? runId : null;
  const { error } = await createAssessment(offerId, check.input, result, settings, agentRunId);
  if (error) return fail(error);
  revalidatePath('/');
  revalidatePath(`/offers/${offerId}`);
  return { status: 'success', message: 'Assessment saved.', errors: {}, values, attempt };
}




// One click: the bounded AI agent prepares the draft, then the owner's plain-code rules work out
// the verdict from it, using the stock and condition staff entered. The verdict is saved as
// "not confirmed" until a person confirms it. Nothing is bought.
export async function prepareDraft(_prev, formData) {
  const offerId = field(formData, 'offer_id');
  const extra = (typeof formData.get('staff_notes') === 'string' ? formData.get('staff_notes') : '').slice(0, 1000);
  const paste = {
    link: field(formData, 'sales_link').slice(0, 500),
    currency: field(formData, 'sales_currency'),
    rows: (typeof formData.get('sales_rows') === 'string' ? formData.get('sales_rows') : '').slice(0, 3000),
  };
  const values = {
    stock_count: field(formData, 'stock_count'), condition: field(formData, 'condition'),
    rookie_card: ['yes', 'no'].includes(field(formData, 'rookie_card')) ? field(formData, 'rookie_card') : '',
    sales_link: paste.link, sales_currency: paste.currency, sales_rows: paste.rows,
  };
  const attempt = Date.now();
  let notes = extra;
  const fail = (message, errors = {}) => ({ status: 'error', message, errors, notes: extra, values, attempt });
  if (!OFFER_ID_PATTERN.test(offerId)) return fail('This offer could not be found.');
  if (paste.rows.trim() && !/^https?:\/\//i.test(paste.link)) {
    return fail('Please fix the highlighted fields.', { sales_link: 'Paste the address of the page the sales came from.' });
  }
  if (paste.rows.trim()) {
    // CardScout writes the explanation for the AI; staff only pasted the link, currency and rows.
    const { offer: o } = await getOffer(offerId);
    notes = [buildSalesNote(o, paste), extra && `Other notes from staff: ${extra}`].filter(Boolean).join('\n\n');
  }

  // Check what only a person can know before spending an AI run.
  const errors = {};
  if (!/^\d+$/.test(values.stock_count) || Number(values.stock_count) > 1000) errors.stock_count = 'Enter the number of copies in stock (0 if none).';
  if (!['acceptable', 'not_acceptable', 'defect', 'unsure'].includes(values.condition)) errors.condition = 'Choose a condition.';
  if (Object.keys(errors).length) return fail('Please fix the highlighted fields.', errors);

  if (!process.env.AGENT_PASSCODE) return fail('AI drafts are locked: AGENT_PASSCODE is not set on the server.');
  const jar = await cookies();
  if (!isRemembered(jar)) {
    if (!passcodeOk(formData.get('passcode'))) return fail('Wrong passcode. Nothing was run.');
    // Remember the passcode on this device only if staff ticked the box.
    if (formData.get('remember') === 'on') jar.set(AGENT_COOKIE, agentToken(), cookieOptions());
  }
  if (!process.env.ANTHROPIC_API_KEY) return fail('AI drafts are not set up yet: ANTHROPIC_API_KEY is missing on the server.');
  if ((await countRunsLastDay()) >= DAILY_LIMIT) {
    return fail(`The daily limit of ${DAILY_LIMIT} AI drafts has been reached. Try again tomorrow or enter the evidence by hand.`);
  }

  const facts = {
    stock_count: Number(values.stock_count),
    condition: { acceptable: 'meets the standard', not_acceptable: 'below the standard', defect: 'has a defect', unsure: 'unsure' }[values.condition],
    rookie_card: values.rookie_card || null,
  };
  // Prices are already pasted, so the agent only needs to research the player.
  const options = { maxSearches: paste.rows.trim() ? SEARCHES_WITH_SALES : undefined };
  const done = (message, status = 'success') => ({ status, message, errors: {}, notes: '', values: { stock_count: values.stock_count, condition: values.condition, rookie_card: values.rookie_card }, attempt });

  // Background: save a "running" row, answer straight away, and let the AI work after the response.
  // Staff can move to the next card; the offer page updates itself when the verdict is ready.
  const started = await startInBackground(offerId, notes, facts, values, options);
  if (started.id) {
    revalidatePath('/');
    revalidatePath(`/offers/${offerId}`);
    return done('Working on it. This takes about a minute: you can start the next card and come back.', 'running');
  }
  if (started.error) return fail(started.error);

  // database/010_background_runs.sql not run yet: run it here and wait, as before.
  const run = await runAgent(offerId, notes, facts, options);
  const { id: runId, error } = await saveRun(run);
  revalidatePath('/');
  revalidatePath(`/offers/${offerId}`);
  if (error) return fail(error);
  if (run.status !== 'completed') return fail(`The AI draft did not finish: ${run.error}`);
  return done(await verdictFromRun(offerId, run, runId, values));
}

// A person confirms the verdict CardScout prepared.
export async function confirmVerdict(formData) {
  const offerId = field(formData, 'offer_id');
  const assessmentId = field(formData, 'assessment_id');
  if (!OFFER_ID_PATTERN.test(offerId) || !OFFER_ID_PATTERN.test(assessmentId)) redirect('/');
  const { error } = await confirmAssessment(assessmentId, offerId);
  revalidatePath('/');
  revalidatePath(`/offers/${offerId}`);
  redirect(`/offers/${offerId}?msg=${error ? 'confirm-failed' : 'confirmed'}`);
}

// Removes the remembered passcode from this device.
export async function forgetPasscode(formData) {
  const offerId = field(formData, 'offer_id');
  (await cookies()).delete(AGENT_COOKIE);
  redirect(OFFER_ID_PATTERN.test(offerId) ? `/offers/${offerId}` : '/');
}

// Staff tap the version on the card from SportsCardsPro's list. CardScout saves that version, gets its
// price and works out the verdict again from the same AI research. No new AI run, nothing to retype.
export async function pickVersion(formData) {
  const offerId = field(formData, 'offer_id');
  const productId = field(formData, 'product_id');
  if (!OFFER_ID_PATTERN.test(offerId)) redirect('/');
  const back = (msg) => redirect(`/offers/${offerId}?msg=${msg}`);
  if (!isRemembered(await cookies())) back('pick-locked');
  const [{ offer }, { settings }, { run }, { assessment }] = await Promise.all([getOffer(offerId), getSettings(), getLatestRun(offerId), getLatestAssessment(offerId)]);
  const option = run?.price_guide?.options?.find((o) => o.id === productId);
  if (!offer || !settings || run?.status !== 'completed' || !option) back('pick-failed');
  const rates = effectiveRates(settings, await getAudRates());
  const guide = await priceForPick(productId, { ...offer, variant: option.variant }, { rate: rates?.USD ?? null, adjust: Number(settings.overseas_adjust ?? 1) || 1 });
  // Keep the list of versions for the market line, and the options in case staff need to pick again.
  const saved = { ...guide, versions: [...new Set(run.price_guide.options.map((o) => o.variant))], options: run.price_guide.options };
  const [{ error: vErr }, { error: gErr }] = await Promise.all([
    setOfferVariant(offerId, option.variant),
    setRunPriceGuide(run.id, saved),
  ]);
  if (vErr || gErr) back('pick-failed');
  const values = {
    stock_count: String(assessment?.stock_count ?? 0),
    condition: assessment?.condition ?? 'acceptable',
    // Keep the earlier rookie answer (staff's or the AI's); it does not depend on the version.
    rookie_card: ['yes', 'no'].includes(assessment?.rookie_card) ? assessment.rookie_card : '',
  };
  await verdictFromRun(offerId, { ...run, price_guide: saved }, run.id, values);
  revalidatePath('/');
  back(guide.found ? 'picked' : 'picked-no-price');
}

// The owner decides a card: Buy, Don't buy or Offer $X, with an optional reason. It is saved next to
// CardScout's suggestion, so future cards can show it. Nothing is bought.
export async function decideOffer(_prev, formData) {
  const offerId = field(formData, 'offer_id');
  const values = { decision: field(formData, 'decision'), offer_aud: field(formData, 'offer_aud'), reason: field(formData, 'reason'), learn: formData.get('learn') === 'on' };
  const fail = (message, errors = {}) => ({ status: 'error', message, errors, values, attempt: Date.now() });
  if (!OFFER_ID_PATTERN.test(offerId)) return fail('This offer could not be found.');
  const jar = await cookies();
  if (!isRemembered(jar)) {
    if (!passcodeOk(formData.get('passcode'))) return fail('Wrong team passcode. Nothing was saved.', { passcode: 'Wrong team passcode.' });
    jar.set(AGENT_COOKIE, agentToken(), cookieOptions());
  }
  const { offer } = await getOffer(offerId);
  if (!offer) return fail('This offer could not be found.');
  const check = validateDecision(values, offer.asking_price_aud);
  if (!check.ok) return fail('Please fix the highlighted part.', check.errors);
  const [{ assessment }, { settings }] = await Promise.all([getLatestAssessment(offerId), getSettings()]);
  const learn = formData.get('learn') === 'on';
  const { error, saved } = await saveOwnerDecision(offer, assessment, { ...check.input, learn }, rulesHit(offer, assessment, settings));
  if (error) return fail(error);
  // Same card still waiting for him: work it out again with what he just decided.
  const changed = learn && settings ? await applyToWaiting(saved, settings) : 0;
  revalidatePath('/');
  revalidatePath('/review');
  revalidatePath(`/offers/${offerId}`);
  redirect(`/offers/${offerId}?msg=decided${changed ? `&also=${changed}` : ''}`);
}

// Add or replace the card's photo from the card page.
export async function addPhoto(_prev, formData) {
  const offerId = field(formData, 'offer_id');
  if (!OFFER_ID_PATTERN.test(offerId)) return { status: 'error', message: 'This offer could not be found.' };
  const { error, skipped } = await savePhoto(offerId, formData.get('photo'));
  if (error || skipped) return { status: 'error', message: error ?? 'Choose a photo first.' };
  revalidatePath('/');
  revalidatePath('/review');
  revalidatePath(`/offers/${offerId}`);
  return { status: 'success', message: '' };
}
